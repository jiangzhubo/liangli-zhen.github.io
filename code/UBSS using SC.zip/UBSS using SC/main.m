
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% This is the main function for running UBSS-SC. 
% S is is consist of 4 speech signals with 15000 time instant.
% A is the mixing matrix
% X is the observed mixtures
% EA is the estimated mixing matrix
% E_Source is the recovered sources
%----------------------------------------------------------------------------------
% Copyright @ Liangli Zhen, Machine Intelligence Lab, Sichuan University, 2016
% Reference: L. Zhen, D. Peng, Z. Yi, Y. Xiang, P. Chen, "Underdetermined
% Blind Source Separation Using Sparse Coding",  IEEE Trans. on Neural
% Networks and Learning Systems, to be published in 2016.
%
% Please cite the above mentioned paper if this matlab code package has
% any help to you.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
clear all; close all;

% Load the speech sources
load 'speech_sources.mat';
sample_num = size(S,2);

% Plot the source signals
figure;
subplot('position',[0.025 0.1 0.2 0.8]) ;
plot(S(1,:),'k');


subplot('position',[0.275 0.1 0.2 0.8]) ;
plot(S(2,:),'k');


subplot('position',[0.525 0.1 0.2 0.8]) ;
plot(S(3,:),'k');


subplot('position',[0.775 0.1 0.2 0.8]) ;
plot(S(4,:),'k');
set(gcf, 'position', [500 300 1000 150]);


A = [  0.5877    0.6025    0.5358    0.7078
    0.4494   -0.5525    0.6552   -0.4767
    0.6728   -0.5760   -0.5325    0.5212];
% Generate the instaneous mxitures
X = A * S(1:4, :);

source_num = 4;

% Plot the observed mixtures
figure;
subplot('position',[0.15 0.1 0.2 0.8]) ;
plot(X(1,:),'k');

subplot('position',[0.4 0.1 0.2 0.8]) ;
plot(X(2,:),'k');

subplot('position',[0.65 0.1 0.2 0.8]) ;
plot(X(3,:),'k');

set(gcf, 'position', [500 500 1000 150]);
[EA, ES] = sspdmethod(A,X,0.01);

% Compute the error of the estimated mixing matrix to the mixing
% matrix ground truth.
[ea_error,es_error] = evaluate(A,S,EA,ES)

E_source = ES;

% Plot the recovered signals
figure;
subplot('position',[0.025 0.1 0.2 0.8]) ;
plot(E_source(1,:),'k');


subplot('position',[0.275 0.1 0.2 0.8]) ;
plot(E_source(2,:),'k');


subplot('position',[0.525 0.1 0.2 0.8]) ;
plot(E_source(3,:),'k');


subplot('position',[0.775 0.1 0.2 0.8]) ;
plot(E_source(4,:),'k');
set(gcf, 'position', [500 300 1000 150]);
