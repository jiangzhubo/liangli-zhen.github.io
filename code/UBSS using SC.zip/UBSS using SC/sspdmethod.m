
function [EA, ES] = sspdmethod(A,X,lambda)
tic
sample_num = size(X,2);
% Using short-time Fourier transform on the mixtures
wlen=1024;
timestep=512;
numfreq=1024;
% Analysis window is a Hammingwindow
awin=hamming(wlen);
swin =awin;

tfmat1 = tfanalysis(X(1,:)',awin,timestep, numfreq);
rtfmat1 = reshape(tfmat1,1,[]);
Xtfmat = zeros(size(X,1),length(rtfmat1));
Xtfmat(1,:) = rtfmat1;
for i = 2:size(X,1)
    tfmat_temp = tfanalysis(X(i,:)',awin,timestep, numfreq);
    rtfmat_temp = reshape(tfmat_temp,1,[]);
    Xtfmat(i,:) = rtfmat_temp;
end

tfmat_norm = sum(abs(Xtfmat).^2, 1);

% Select the data points which have more energy than a given level
rau = 10;
Mtfmat = Xtfmat(:,tfmat_norm> max(mean(tfmat_norm)/rau,1E-3));
while size(Mtfmat,2) < size(Xtfmat,2)/10 || size(Mtfmat,2) < 3000
    rau = 2*rau;
    Mtfmat = Xtfmat(:,tfmat_norm> max(mean(tfmat_norm)/rau,1E-4));
end

Mtfmat = abs(Mtfmat).*sign(real(Mtfmat));

% Norminized time-frequency (TF) samples.
XD = Mtfmat./repmat(sum(Mtfmat.^2).^(1/2),size(X,1),1).*repmat(sign(Mtfmat(1,:)),size(X,1),1);
% XD = Xtfmat;
clear Mtfmat;
% Sampling part of the TF points to estimate the mixing matrix such that it
% is faster than using all the samples.

OMEGA = [];

%%
while size(OMEGA, 2) < 300
    sampling_num = 3000;
    sampling_index = randperm(size(XD,2),sampling_num);
    XDT = XD(:,sampling_index);
    W = sparse_representation(XDT,lambda);
    
    omega_threshold = 1e-4;
    OMEGAT = XDT(:,(sum(abs(W)<omega_threshold) ==(size(W,1)-1))&(sum(abs(W)>1-10*omega_threshold) ==1));
    while size(OMEGAT,2) ==0
        omega_threshold = omega_threshold*10;
        OMEGAT =XDT(:,(sum(abs(W)<omega_threshold) ==(size(W,1)-1))&(sum(abs(W)>1-10*omega_threshold) ==1));
    end
     OMEGA=[OMEGA  OMEGAT];
     fprintf([' *** The omega_threshold = ' num2str(omega_threshold) '  ']);

    fprintf([' *** The lambda = ' num2str(lambda) '  *****OMEGASIZE = ' num2str(size(OMEGA,2)) '   ']);
end

%% Using this code would make the proposed method more stable.
% while size(OMEGA, 2) < 1000
%     sampling_num = 5000;
%     sampling_index = randperm(size(XD,2),sampling_num);
%     XDT = XD(:,sampling_index);
%     W = sparse_representation(XDT,lambda);
%     
%     omega_threshold = 1e-4;
%     OMEGA = [OMEGA XDT(:,(sum(abs(W)<omega_threshold) ==(size(W,1)-1))&(sum(abs(W)>0.99) ==1))];
%     fprintf([' *** The lambda = ' num2str(lambda) '  *****OMEGASIZE = ' num2str(size(OMEGA,2)) '   ']);
% end

fprintf([' *** The lambda = ' num2str(lambda) '  *****OMEGASIZE = ' num2str(size(OMEGA,2)) '   ']);

for i = 1:size(OMEGA, 2)
    if OMEGA(1,i) < 0
        OMEGA(:,i) =  -OMEGA(:,i);
    end
end


[H_est_first_clustering] = hierachical_clustering(OMEGA',size(A,2),size(A,1),1);
H_est_first_clustering = H_est_first_clustering./repmat(sum(H_est_first_clustering.^2).^(1/2),size(A,1),1);


EA = zeros(size(A));
for i = 1:size(A,2)
    [~,u2]=max(abs(A(:,i)'*H_est_first_clustering));
    
    EA(:,i) = H_est_first_clustering(:,u2);
    if A(:,i)'*H_est_first_clustering(:,u2)<0
        EA(:,i) = -EA(:,i);
    end
    
    H_est_first_clustering(:,u2) = [];
end
tElapsed=toc;
fprintf([' *** The time cost of mixing matrix estimation for the proposed method is ' num2str(tElapsed) ' seconds' '\n']);

tic;
% Recover the time-frequency representations of the source signals
ES_TF = source_recovery2(Xtfmat,EA);

% Reshape the estimated signals as the time-frequency matrix form for each
% source.
ES = zeros(4, sample_num);
for i = 1:size(A,2)
    estfmat = reshape(ES_TF(i,:),numfreq,[]);
    est_temp = tfsynthesis(estfmat,sqrt(2)*awin/1024, timestep, numfreq);
    ES(i,:) = est_temp(1:sample_num)./max(abs(est_temp(1:sample_num)));
end
tElapsed=toc;
fprintf([' *** The time cost of source recovery for the proposed method is ' num2str(tElapsed) ' seconds' '\n']);
end