% Source recovery by projecting the inputpoints into C_N^(m-1) subspaces,
% and get the recover coefficients with which has minimal reconstruction residual.
function eS = source_recovery2(X, A)
X = X(1:size(A,1),:);
n = size(A,2);
m = size(A,1);
N = size(X,2);
Combine = nchoosek(1:n, m-1);
eS = zeros(n, size(X,2));

residual = zeros(N, size(Combine,1));
for j = 1:size(Combine,1)
    residual(:,j) = sum(abs(X - A(:,Combine(j,:))*(pinv(A(:,Combine(j,:)))* X)).^2,1);
end

[~,u] = min(residual,[],2);
for i = 1:size(Combine,1)
    idx = find(u==i);
    eS(Combine(i,:),idx) = pinv(A(:,Combine(i,:)))* X(:,idx);
end
