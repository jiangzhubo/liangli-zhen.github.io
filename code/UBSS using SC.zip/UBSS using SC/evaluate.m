function [ea_error, es_error] = evaluate(A,S,EA,ES)
A = A(1:size(EA,1),:);
sources_num = size(S,1);
delta1 = zeros(sources_num,1);
for i = 1:sources_num
    delta1(i,1) = (A(:,i)'*EA(:,i))/(EA(:,i)'*EA(:,i));
    EA(:,i) = EA(:,i).*delta1(i,1);
end
error = 0;
for i = 1:sources_num
    error = error + (1-(A(:,i)'*EA(:,i)/(norm(A(:,i))*norm(EA(:,i)))));
end
ea_error = error/sources_num;
delta2 = zeros(size(S,1),1);
for i = 1:sources_num
    delta2(i,1) = (S(i,:)*ES(i,:)')/(ES(i,:)*ES(i,:)');
    ES(i,:) = ES(i,:).*delta2(i,1);
end
error2 = 0;
for i = 1:sources_num
    error2 = error2 + (norm(S(i,:)-ES(i,:)).^2)/(norm(S(i,:)).^2);
end
es_error = 10*log10(error2/sources_num);
end