%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Liangli Zhen
% llzhen@outlook.com
% locally linear representation for image clustering
% Feb., 2014

% this file used for finding a good parameter combination

close all;
clear all;
clc;

%% --------------------------------------------------------------------------
addpath ('..\usage\');
addpath ('..\clustering\');
addpath ('..\data\');

nClassArr = 38;

for nClassI=1:length(nClassArr)        
% loading data
CurData = 'ExYaleB_48_42PCA114';
load (CurData);

% --- parameters configuration
par.nRepeat = 1;
par = LLRParameterConfig(par);
par.nClass = nClassArr(nClassI);

% creat a dir for store logs and final result
par.NameStr = ['.\LLRgraph' '_' CurData '_cluster#' num2str(par.nClass) '_EigenF' num2str(par.nDim) '_K#' num2str(length(par.K)) '_nRepeat#' num2str(length(par.nRepeat))];

accuracy = [];
nmi = [];
% --- split DAT into two parts, using the first par.nClass class to test
dat   =   double(dat(:,labels<=par.nClass));
labels     =   labels(labels<=par.nClass);
% dat = FeatureEx(DAT, par);
% clear DAT;
par.MaxK=300;
fid = fopen([ par.NameStr '.txt'], 'a+');
pos = 1;
for i = 1:length(par.K)
    fprintf([' \n--------- Running the experiment when K = ' num2str(par.K(i)) ' ---------\n ']);     
    fprintf(fid, [' \n--------- Running the experiment when K = ' num2str(par.K(i)) ' ---------\n ']);  
    for k=1:length(par.Lambda)
        tic;
        coef = llr(par.Lambda(k),dat,par.MaxK);
        tElapsed=toc;
        fprintf([' *** The time cost for getting LLR coef matrix is ' num2str(tElapsed) ' seconds, where | k = ' num2str(par.K(i))  '\n']);
        fprintf(fid, [' *** The time cost for getting LLR coef matrix is ' num2str(tElapsed) ' seconds, where | k = ' num2str(par.K(i))  '\n']);
        % --- Building Adjacency graph
        tic;
        CKSym = BuildAdjacency(coef,par.K(i));
        tElapsed=toc;
        fprintf([' *** The time cost for building adjacency matrix  is ' num2str(tElapsed) ' seconds, where | k = ' num2str(par.K(i))  '\n']);
        fprintf(fid, [' *** The time cost for building adjacency matrix  is ' num2str(tElapsed) ' seconds, where | k = ' num2str(par.K(i)) '\n']);
        
        for j = 1:par.nRepeat
            % --- perform spectral clustering, 3 clusters are tested, e.g.
            % Unnormalized Method, Random Walk Method and Normalized Symmetric
            tic;
            [Predict_label, SingVals, LapKernel] = SpectralClustering(CKSym,par.nClass,par.SCidx);
            tElapsed=toc;
            fprintf([' * The ' num2str(j) 'th time cost for clustering is ' num2str(tElapsed) ' seconds! , where | k = ' num2str(par.K(i))  ' | nRepeat = ' num2str(j) '\n']);
            fprintf(fid, [' * The ' num2str(j) 'th time cost for clustering is ' num2str(tElapsed) ' seconds, where | k = ' num2str(par.K(i))  ' | nRepeat = ' num2str(j) '\n']);
            
            % if the value is nan, then randomly assign a label, maybe a
            % more suitable strategy is to reject label assignment as it is a outlier
            for ii = 1:size(Predict_label,1)
                for jj = 1:size(Predict_label,2)
                    if isnan(Predict_label(ii,jj))==1
                        tmp = unique([labels]);
                        tmp2= tmp(randperm(length(tmp)));
                        Predict_label(ii,jj) = tmp2(1);
                    end;
                end
            end;
            clear ii jj tmp tmp2;
            % --- get accuracy and normalized mutual information for clustering result
            [t_accuracy t_nmi]= CalMetricOfCluster(Predict_label,labels);
            t_accuracy = t_accuracy./100;
            accuracy(i,k,j) = t_accuracy;
            nmi(i,k,j) = t_nmi;
            pos = pos + 1;
            fprintf([' | the ' num2str(j) 'th result for k = ' num2str(par.K(i)) 'lambda=' num2str(par.Lambda(k)) '\n']);
            fprintf([' + The accuracy                      scores are: ' num2str(t_accuracy) '\n']);
            fprintf([' + The normalized mutual information scores are: ' num2str(t_nmi) '\n']);
            
            fprintf(fid, [' | the ' num2str(j) 'th result for k = ' num2str(par.K(i)) 'lambda=' num2str(par.Lambda(k)) '\n']);
            fprintf(fid, [' + The accuracy                      scores are: ' num2str(t_accuracy) '\n']);
            fprintf(fid, [' + The normalized mutual information scores are: ' num2str(t_nmi) '\n']);
        end;
    end
end;
fclose(fid);
clear tElapsed fid ans Predict_label coef1 coef2 kk trls ttls dat DAT;
clear LapKernel SingVals i j pos t_accuracy t_nmi k dat labels tmp_iter tmp_x;
% if length(par.lambda) > 1 || length(par.nRepeat) >1 
clear CKSym Predict_label coef;
% end
save (par.NameStr);

end