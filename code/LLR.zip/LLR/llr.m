%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Liangli Zhen
% llzhen@outlook.com
% locally linear representation for image clustering
% Feb., 2014

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%USE ||SC||_2 + ||X-XC||_2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [W] = llr(lambda,X,K)
[D,N] = size(X);
fprintf(1,'LLR running on %d points in %d dimensions\n',N,D);


% STEP1: COMPUTE PAIRWISE DISTANCES & FIND NEIGHBORS 
fprintf(1,'-->Finding %d nearest neighbours.\n',K);

X2 = sum(X.^2,1);
X=double(X);
distance = repmat(X2,N,1)+repmat(X2',1,N)-2*X'*X;

[sorted,index] = sort(distance);
neighborhood = index(2:(1+K),:);



% STEP2: SOLVE FOR RECONSTRUCTION WEIGHTS
% fprintf(1,'-->Solving for reconstruction weights.\n');

if(K>D) 
%   fprintf(1,'   [note: K>D; regularization will be used]\n'); 
  tol=1e-3; % regularlizer in case constrained fits are ill conditioned
else
%   tol=1e-6;
  tol=0;
end


W = zeros(N,N);
WK=zeros(K,1);  
for ii=1:N
   z = X(:,neighborhood(:,ii))-repmat(X(:,ii),1,K); % shift ith pt to origin
   C = (1-lambda)*z'*z+lambda*(diag(sorted(2:1+K,ii)));   
   C = C + eye(K,K)*tol*trace(C);                   % regularlization (K>D)

   WK = C\ones(K,1);                           % solve Cw=1
   WK = WK/sum(WK);                  % enforce sum(w)=1
   W(neighborhood(:,ii),ii)=WK;
end;
