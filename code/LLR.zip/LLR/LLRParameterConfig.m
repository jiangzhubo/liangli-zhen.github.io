function par = LLRParameterConfig(par)
% --------- data configuration
par.nClassArr=[];
par.nDim               =   114; % the eigenfaces dimension
% --- optimization algorithms configuration
par.MaxK=300;
% par.K             =  2:12; 
% par.Lambda=[1e-7,1e-5,0.001,0.01,0.05,1e-1,0.2,0.5,0.7,0.9,0.99];
par.K             =  5; 
par.Lambda = [0.01,0.05];

% clustering algorithm configuration
par.SCidx              =   3; % 0-test three spectral clusterings, 1-only Unnormalized Method, 2-Random Walk Method and 3-Normalized Symmetric

