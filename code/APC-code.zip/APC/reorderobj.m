function list= reorderobj(X_OBJ)
%% Rearranging the order of objectives according to the conflict/harmony between objectives.
% Author: Lianli Zhen (llzhen@outlook.com)
% Date: 3 May 2017
% Input: a matrix contains the objective values of solutions. 
% Each row represents a solution.
% Output: the rearranged result for the order of objectives.

% Reference:
%   [1] L. Zhen, M. Li, R. Cheng, D. Peng, X. Yao, �Adjusting Parallel Coordinates for Investigating
%   Multi-Objective Search,� in Proc. International Conference on Simulated Evolution and Learning, 2017, in press.
%   Copyright 2017 Liangli Zhen.

%% Input the objective values of all candidate solutions in each generation.
F = X_OBJ';
obj_num = size(F,2);

%% Calculate the Spearman's rank correlation between objectives.
corF  = corr(F, F, 'type', 'Spearman');

% Remove the impact of self correlations
corF(logical(eye(size(corF)))) = 0;
% Double direction connections, delete one side.
corF = triu(corF);

%% Sort the correlations as a queue
[~,idx]= sort(abs(corF(:)),'descend');
[row,col] = ind2sub(size(corF),idx);

% Initial a flag vector to denote the connections to each objective
flag = zeros(1, obj_num);
list = cell(1,1);
i = 1; j = 0;
while sum(flag)< 2*obj_num-3 % ensure all objectives are connected into the parallel coordinates.
    if flag(row(i))==0 && flag(col(i))==0
        flag(row(i)) = flag(row(i))+1;
        flag(col(i)) = flag(col(i))+1;
        list{j+1} = [row(i) col(i)];
        j = j+1;
    elseif flag(row(i))==0 && flag(col(i)) ==1
        for k=1:j
            if list{k}(1)== col(i)
                list{k}(2:end+1) = list{k};
                list{k}(1) = row(i);
                flag(row(i)) = flag(row(i))+1;
                flag(col(i)) = flag(col(i))+1;
            elseif list{k}(end)== col(i)
                list{k}(end+1) = row(i);
                flag(row(i)) = flag(row(i))+1;
                flag(col(i)) = flag(col(i))+1;
            end
        end
    elseif flag(row(i))==1 && flag(col(i)) ==0
        for k=1:j
            if list{k}(1)== row(i)
                list{k}(2:end+1) = list{k};
                list{k}(1) = col(i);
                flag(row(i)) = flag(row(i))+1;
                flag(col(i)) = flag(col(i))+1;
            elseif list{k}(end)== row(i)
                list{k}(end+1) = col(i);
                flag(row(i)) = flag(row(i))+1;
                flag(col(i)) = flag(col(i))+1;
            end
        end
    elseif flag(row(i))==1 && flag(col(i)) ==1
        for k2=1:j
            for l= k2+1:j
                if list{k2}(1)== row(i)&&list{l}(end)== col(i)
                    list{k2} = [list{l} list{k2}];
                    if l<j
                        list(l:j-1) = list(l+1:j);
                    end
                    list{j} =[];
                    j = j-1;
                    flag(row(i)) = flag(row(i))+1;
                    flag(col(i)) = flag(col(i))+1;
                elseif list{k2}(1)== row(i)&& list{l}(1)== col(i)
                    list{k2} = [fliplr(list{l}) list{k2}];
                    if l<j
                        list(l:j-1) = list(l+1:j);
                    end
                    list{j} =[];
                    j = j-1;
                    flag(row(i)) = flag(row(i))+1;
                    flag(col(i)) = flag(col(i))+1;
                    
                elseif list{k2}(end)== row(i)&&list{l}(end)== col(i)
                    
                    list{k2} = [list{k2} fliplr(list{l})];
                    if l<j
                        list(l:j-1) = list(l+1:j);
                    end
                    list{j} =[];
                    j = j-1;
                    flag(row(i)) = flag(row(i))+1;
                    flag(col(i)) = flag(col(i))+1;
                elseif list{k2}(end)== row(i)&&list{l}(1)== col(i)
                    list{k2} = [list{k2} list{l}];
                    if l<j
                        list(l:j-1) = list(l+1:j);
                    end
                    list{j} =[];
                    j = j-1;
                    flag(row(i)) = flag(row(i))+1;
                    flag(col(i)) = flag(col(i))+1;
                end
            end
        end
    end    
    i = i+1;
end
figure('units','normalized','position',[0 0.5 .4 .4]);
[FrontNo,~] = NDSort(F(:,list{1}),inf);
parallelcoords(F(:,list{1}),'Group',FrontNo);
xlim([1 obj_num]);
set(gca,'XTick',[1:obj_num]);
set(gca,'xticklabels',list{1});
xlabel('Objective No.');
ylabel('Objective Values');
set(gca,'fontsize',18, 'GridLineStyle', '-.','LineWidth', 2);
box on;
legend('off')
figure('units','normalized','position',[.5 .5 .4 .4]);
plot(F','k');
xlim([1 obj_num]);
set(gca,'XTick',1:obj_num);
xlabel('Objective No.');
ylabel('Objective Values');
set(gca,'fontsize',18, 'GridLineStyle', '-.','LineWidth', 2);
box on;
pause(0.5);
end