This folder contains all the solution sets used in the paper. 

In each file, each row corresponds to a solution and each column corresponds to a objective (from f1 to fm).

