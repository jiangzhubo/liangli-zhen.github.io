function varargout = DPF3(Operation,Global,input)
% <problem> <DPF>
% Multiobjective Test Problems with Degenerate Pareto Fronts
% EM ---  2 --- Dimensionality of the true Pareto front
% operator --- EAreal

%--------------------------------------------------------------------------
% This code is the definition of DPF3 in the reference:
% Liangli Zhen, Miqing Li, Ran Cheng, Dezhong Peng, and Xin Yao,
% Multiobjective Test Problems with Degenerate Pareto Fronts.
% By Liangli Zhen (llzhen@outlook.com)
%--------------------------------------------------------------------------

EM = Global.ParameterSet(2);
EM = max(min(EM,Global.M),2);

% Chaos based random number generator is used to generate weight matrix W.
a = 3.8; c0 = 0.1;
chaos = @(c) a*c*(1 - c);
c = chaos(c0);
C = zeros(1, Global.M - EM);
C(1, 1) = c;
for i = 2:(Global.M - EM)
    c = chaos(c);
    C(1, i) = c;
end
[eta, ~] = sort(C);
switch Operation
    case 'init'
        Global.M          = 3;
        Global.D          = Global.M + 4;
        Global.lower      = zeros(1,Global.D);
        Global.upper      = ones(1,Global.D);
        Global.operator   = @EAreal;
        
        
        PopDec    = rand(input,Global.D);
        varargout = {PopDec};
    case 'value'
        PopDec = input;
        [N,D]  = size(PopDec);
        M      = EM;
        PopDec(:,1:M-1) = PopDec(:,1:M-1).^100;
        g      = sum((PopDec(:,M:end)-0.5).^2, 2);
        PopObj = repmat(1+g,1,M) - repmat(1+g,1,M).*fliplr(cumprod([ones(N,1),cos(PopDec(:,1:M-1)*pi/2)],2)).*[ones(N,1),sin(PopDec(:,M-1:-1:1)*pi/2)];
 
        PopObjTemp = ones(N, Global.M);   
        PopObjTemp(:, 1:EM-1) = PopObj(:, 1:EM-1);
        PopObjTemp(:, EM:Global.M) = repmat(PopObj(:, EM), 1, Global.M-EM+1);
        PopObjTemp(PopObj(:, EM) > eta(1,1), EM) = eta(1,1);
        for i = EM+1:Global.M-1
            PopObjTemp(PopObj(:,EM) < eta(1,i-EM), i) = eta(1,i-EM);
            PopObjTemp(PopObj(:,EM) > eta(1,i-EM+1), i) = eta(1,i-EM+1);
        end
        PopObjTemp(PopObj(:, EM)< eta(1,Global.M-EM), Global.M) = eta(1,Global.M-EM);
        
        PopObj = PopObjTemp;
        
        PopCon = [];
        varargout = {input,PopObj,PopCon};
    case 'PF'
        f = UniformPoint(input,EM);
        f = f./repmat(sqrt(sum(f.^2,2)),1,EM);
        f = (1-f);
        
        fTemp = ones(size(f,1), Global.M);   
        fTemp(:, 1:EM-1) = f(:, 1:EM-1);
        fTemp(:, EM:Global.M) = repmat(f(:, EM), 1, Global.M-EM+1);
        fTemp(f(:, EM) > eta(1,1), EM) = eta(1,1);
        for i = EM+1:Global.M-1
            fTemp(f(:,EM) < eta(1,i-EM), i) = eta(1,i-EM);
            fTemp(f(:,EM) > eta(1,i-EM+1), i) = eta(1,i-EM+1);
        end
        fTemp(f(:, EM)< eta(1,Global.M-EM), Global.M) = eta(1,Global.M-EM);
        
        f = fTemp;
        varargout = {f};
end
end
function Output = s_decept(y,A,B,C)
    Output = 1+(abs(y-A)-B).*(floor(y-A+B)*(1-C+(A-B)/B)/(A-B)+floor(A+B-y)*(1-C+(1-A-B)/B)/(1-A-B)+1/B);
end