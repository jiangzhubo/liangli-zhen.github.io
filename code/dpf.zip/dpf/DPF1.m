function varargout = DPF1(Operation,Global,input)
% <problem> <DPF>
% Multiobjective Test Problems with Degenerate Pareto Fronts
% EM ---  2 --- Dimensionality of the true Pareto front
% operator --- EAreal

%--------------------------------------------------------------------------
% This code is the definition of DPF1 in the reference:
% Liangli Zhen, Miqing Li, Ran Cheng, Dezhong Peng, and Xin Yao,
% Multiobjective Test Problems with Degenerate Pareto Fronts.
% By Liangli Zhen (llzhen@outlook.com)
%--------------------------------------------------------------------------

EM = Global.ParameterSet(2);
EM = max(min(EM,Global.M),2);
% Chaos based random number generator is used to generate weight matrix W.
a = 3.8; c0 = 0.1;
chaos = @(c) a*c*(1 - c);
c = chaos(c0);
C = zeros(1, EM*(Global.M - EM));
C(1, 1) = c;
for i = 2:EM*(Global.M - EM)
    c = chaos(c);
    C(1, i) = c;
end
U = reshape(C, [EM, Global.M - EM]);
switch Operation
    case 'init'
        Global.M        = 3;
        Global.D        = EM + 9;
        Global.lower    = zeros(1,Global.D);
        Global.upper    = ones(1,Global.D);
        Global.operator = @EAreal;
        
        PopDec    = rand(input,Global.D);
        varargout = {PopDec};
    case 'value'
        PopDec = input;
        [N,D]  = size(PopDec);
        M      = EM;
        
        g      = 100*(D-M+1+sum((PopDec(:,M:end)-0.5).^2-cos(20.*pi.*(PopDec(:,M:end)-0.5)),2));
        PopObj = 0.5*repmat(1+g,1,M).*fliplr(cumprod([ones(N,1),PopDec(:,1:M-1)],2)).*[ones(N,1),1-PopDec(:,M-1:-1:1)];
        
        PopObj = [PopObj PopObj*U];
        PopCon = [];
        
        varargout = {input,PopObj,PopCon};
    case 'PF'
        f = UniformPoint(input,EM)/2;
        f = [f f*U];
        varargout = {f};
end
end