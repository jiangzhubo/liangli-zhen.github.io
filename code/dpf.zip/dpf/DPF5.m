function varargout = DPF5(Operation,Global,input)
% <problem> <DPF>
% Multiobjective Test Problems with Degenerate Pareto Fronts
% EM ---  2 --- Dimensionality of the true Pareto front
% operator --- EAreal


%--------------------------------------------------------------------------
% This code is the definition of DPF5 in the reference:
% Liangli Zhen, Miqing Li, Ran Cheng, Dezhong Peng, and Xin Yao,
% Multiobjective Test Problems with Degenerate Pareto Fronts.
% By Liangli Zhen (llzhen@outlook.com)
%--------------------------------------------------------------------------

EM = Global.ParameterSet(2);
EM = max(min(EM,Global.M),2);
    switch Operation
        case 'init'
            Global.M          = 3;
            Global.D          = Global.M + 9;
            Global.lower      = zeros(1,Global.D);
            Global.upper      = ones(1,Global.D);
            Global.operator   = @EAreal;
            PopDec    = rand(input,Global.D);
            varargout = {PopDec};
        case 'value'
            PopDec = input;
            M      = Global.M;

            g      = sum((PopDec(:,M+1:end)-0.5).^2,2) +  (PopDec(:,M)-PopDec(:,1)).^2;

            PopObj = repmat(1+g,1,M).*fliplr(cumprod([ones(size(g,1),1),cos(PopDec(:,1:M-1)*pi/2)],2)).*[ones(size(g,1),1),sin(PopDec(:,M-1:-1:1)*pi/2)];
            objd = (1+g).*prod(cos(PopDec(:,1:EM-1)*pi/2), 2);
            
            PopObjTemp = PopObj;
            PopObjTemp(PopObj(:,M)>=0.5, 1:M-EM+1) = (sqrt(1/(Global.M-EM+1)))*repmat(objd(PopObj(:,M)>=0.5, 1), 1, M-EM+1);
            
            PopObj = PopObjTemp;
            PopCon = [];
            
            varargout = {input,PopObj,PopCon};
        case 'PF'
            f = UniformPoint(input,Global.M);
            f = f./repmat(sqrt(sum(f.^2,2)),1,Global.M);
            fTemp = f;
            fTemp(f(:, Global.M)>=0.5, 1:Global.M-EM+1) =  (sqrt(1/(Global.M-EM+1)))*repmat(sqrt(1 - sum(f(f(:,Global.M)>=0.5, Global.M-EM+2:Global.M).^2, 2)), 1, Global.M-EM+1);
            f = fTemp;
            varargout = {f};
    end
end