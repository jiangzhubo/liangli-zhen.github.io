function varargout = DPF2(Operation,Global,input)
% <problem> <DPF>
% Multiobjective Test Problems with Degenerate Pareto Fronts
% EM ---  2 --- Dimensionality of the true Pareto front
% operator --- EAreal

%--------------------------------------------------------------------------
% This code is the definition of DPF2 in the reference:
% Liangli Zhen, Miqing Li, Ran Cheng, Dezhong Peng, and Xin Yao,
% Multiobjective Test Problems with Degenerate Pareto Fronts.
% By Liangli Zhen (llzhen@outlook.com)
%--------------------------------------------------------------------------

EM = Global.ParameterSet(2);
EM = max(min(EM,Global.M),2);

% Chaos based random number generator is used to generate weight matrix W.
a = 3.8; c0 = 0.1;
chaos = @(c) a*c*(1 - c);
c = chaos(c0);
C = zeros(1, EM*(Global.M - EM));
C(1, 1) = c;
for i = 2:EM*(Global.M - EM)
    c = chaos(c);
    C(1, i) = c;
end
U = reshape(C, [EM, Global.M - EM]);

switch Operation
    case 'init'
        Global.M        = 3;
        Global.D        = EM + 19;
        Global.lower    = zeros(1,Global.D);
        Global.upper    = ones(1,Global.D);
        Global.operator = @EAreal;
        
        PopDec    = rand(input,Global.D);
        varargout = {PopDec};
    case 'value'
        PopDec = input;
        M      = EM;
        
        PopObj          = zeros(size(PopDec,1),M);
        g               = 1+9*mean(PopDec(:,M:end),2);
        PopObj(:,1:M-1) = PopDec(:,1:M-1);
        PopObj(:,M)     = (1+g).*(M-sum(PopObj(:,1:M-1)./(1+repmat(g,1,M-1)).*(1+sin(3*pi.*PopObj(:,1:M-1))),2));
        
        PopObj = [PopObj (PopObj*U).^2];
        PopCon = [];
        
        varargout = {input,PopObj,PopCon};
    case 'PF'
        interval     = [0,0.251412,0.631627,0.859401];
        median       = (interval(2)-interval(1))/(interval(4)-interval(3)+interval(2)-interval(1));
        X            = ReplicatePoint(input,EM-1);
        X(X<=median) = X(X<=median)*(interval(2)-interval(1))/median+interval(1);
        X(X>median)  = (X(X>median)-median)*(interval(4)-interval(3))/(1-median)+interval(3);
        f            = [X,2*(EM-sum(X/2.*(1+sin(3*pi.*X)),2))];
        
        f = [f (f*U).^2];
        varargout = {f};
end
end

function W = ReplicatePoint(SampleNum,M)
if M > 1
    SampleNum = (ceil(SampleNum^(1/M)))^M;
    Gap       = 0:1/(SampleNum^(1/M)-1):1;
    eval(sprintf('[%s]=ndgrid(Gap);',sprintf('c%d,',1:M)))
    eval(sprintf('W=[%s];',sprintf('c%d(:),',1:M)))
else
    W = (0:1/(SampleNum-1):1)';
end
end